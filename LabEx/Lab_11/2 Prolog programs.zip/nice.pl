nice(X) :- honest(X), gentle(X).
honest(alice).
honest(barbara).
gentle(barbara).